module.exports = function() {
  return {
    appsDetail: require('./appsDetail'),
    pageRule: require('./pageRule'),
	appOverview: require('./appOverview'),
	pageContent: require('./pageContent'),
	pageRes: require('./pageRes'),
	pageEnt: require('./pageEnt'),
	event: require('./event'),
  }
}
