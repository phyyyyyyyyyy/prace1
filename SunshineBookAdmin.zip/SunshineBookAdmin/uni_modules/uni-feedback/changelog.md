## 1.1.1（2024-03-26）
支持支付宝小程序云
## 1.1.0（2022-07-13）
新增，应用[pages_init](https://uniapp.dcloud.io/plugin/publish.html#pages-init)当导入插件到项目工程时，自动合并本插件的页面路由到项目的pages.json
## 1.0.5（2022-07-13）
新增，应用[pages_init](https://uniapp.dcloud.io/plugin/publish.html#pages-init)当导入插件到项目工程时，自动合并本插件的页面路由到项目的pages.json
## 1.0.4（2021-09-26）
为了数据安全，`opendb-feedback`表的`permission`中`delete`，`update`的值默认为`false`
## 1.0.3（2021-08-26）
删除多余的云函数test2