<template>
  <view class="uni-container">
    <uni-forms ref="form" :model="formData" validateTrigger="bind">
      <uni-forms-item name="bookName" label="书名" required>
        <uni-easyinput v-model="formData.bookName"></uni-easyinput>
      </uni-forms-item>
      <uni-forms-item name="author" label="作者" required>
        <uni-easyinput v-model="formData.author"></uni-easyinput>
      </uni-forms-item>
      <uni-forms-item name="publisher" label="出版社" required>
        <uni-easyinput v-model="formData.publisher"></uni-easyinput>
      </uni-forms-item>
      <uni-forms-item name="ISBN" label="ISBN" required>
        <uni-easyinput v-model="formData.ISBN"></uni-easyinput>
      </uni-forms-item>
      <uni-forms-item name="classify" label="分类" required>
        <uni-data-checkbox v-model="formData.classify" :localdata="formOptions.classify_localdata"></uni-data-checkbox>
      </uni-forms-item>
      <uni-forms-item name="coverImage" label="封面">
        <uni-file-picker file-mediatype="image" file-extname="jpg,png" return-type="object" v-model="formData.coverImage"></uni-file-picker>
      </uni-forms-item>
      <uni-forms-item name="price" label="单价" required>
        <uni-easyinput type="number" v-model="formData.price"></uni-easyinput>
      </uni-forms-item>
      <uni-forms-item name="cheapPrice" label="折扣价">
        <uni-easyinput type="number" v-model="formData.cheapPrice"></uni-easyinput>
      </uni-forms-item>
      <uni-forms-item name="restCount" label="余量" required>
        <uni-easyinput type="number" v-model="formData.restCount"></uni-easyinput>
      </uni-forms-item>
      <uni-forms-item name="brief" label="简介">
        <uni-easyinput v-model="formData.brief" type="textarea" autoHeight></uni-easyinput>
      </uni-forms-item>
      <view class="uni-button-group">
        <button type="primary" class="uni-button" style="width: 100px;" @click="submit">提交</button>
        <navigator open-type="navigateBack" style="margin-left: 15px;">
          <button class="uni-button" style="width: 100px;">返回</button>
        </navigator>
      </view>
    </uni-forms>
  </view>
</template>

<script>
  import { validator } from '../../js_sdk/validator/sunshine-book.js';

  const db = uniCloud.database();
  const dbCmd = db.command;
  const dbCollectionName = 'sunshine-book';

  function getValidator(fields) {
    let result = {}
    for (let key in validator) {
      if (fields.includes(key)) {
        result[key] = validator[key]
      }
    }
    return result
  }

  

  export default {
    data() {
      let formData = {
        "bookName": "",
        "author": "",
        "publisher": "",
        "ISBN": "",
        "classify": "",
        "coverImage": null,
        "price": 0,
        "cheapPrice": null,
        "restCount": 0,
        "brief": ""
      }
      return {
        formData,
        formOptions: {
          "classify_localdata": [
            {
              "text": "儿童",
              "value": "儿童"
            },
            {
              "text": "教辅",
              "value": "教辅"
            },
            {
              "text": "文学社科",
              "value": "文学社科"
            },
            {
              "text": "艺术",
              "value": "艺术"
            },
            {
              "text": "经管励志",
              "value": "经管励志"
            },
            {
              "text": "考试法律",
              "value": "考试法律"
            },
            {
              "text": "科技生活",
              "value": "文创"
            }
          ]
        },
        rules: {
          ...getValidator(Object.keys(formData))
        }
      }
    },
    onReady() {
      this.$refs.form.setRules(this.rules)
    },
    methods: {
      
      /**
       * 验证表单并提交
       */
      submit() {
        uni.showLoading({
          mask: true
        })
        this.$refs.form.validate().then((res) => {
          return this.submitForm(res)
        }).catch(() => {
        }).finally(() => {
          uni.hideLoading()
        })
      },

      /**
       * 提交表单
       */
      submitForm(value) {
        // 使用 clientDB 提交数据
        return db.collection(dbCollectionName).add(value).then((res) => {
          uni.showToast({
            title: '新增成功'
          })
          this.getOpenerEventChannel().emit('refreshData')
          setTimeout(() => uni.navigateBack(), 500)
        }).catch((err) => {
          uni.showModal({
            content: err.message || '请求服务失败',
            showCancel: false
          })
        })
      }
    }
  }
</script>
