// 表单校验规则由 schema2code 生成，不建议直接修改校验规则，而建议通过 schema2code 生成, 详情: https://uniapp.dcloud.net.cn/uniCloud/schema


const validator = {
  "bookName": {
    "rules": [
      {
        "required": true,
        "errorMessage": "书名不能为空"
      },
      {
        "format": "string",
        "errorMessage": "书名不能为空"
      }
    ],
    "title": "书名",
    "label": "书名"
  },
  "author": {
    "rules": [
      {
        "required": true,
        "errorMessage": "作者不能为空"
      },
      {
        "format": "string",
        "errorMessage": "作者不能为空"
      }
    ],
    "title": "作者",
    "label": "作者"
  },
  "publisher": {
    "rules": [
      {
        "required": true,
        "errorMessage": "{title}不能为空"
      },
      {
        "format": "string",
        "errorMessage": "{title}不能为空"
      }
    ],
    "title": "出版社",
    "label": "出版社"
  },
  "ISBN": {
    "rules": [
      {
        "required": true,
        "errorMessage": "{title}不能为空"
      },
      {
        "format": "string",
        "errorMessage": "{title}不能为空"
      }
    ],
    "title": "ISBN",
    "label": "ISBN"
  },
  "classify": {
    "rules": [
      {
        "required": true
      },
      {
        "format": "string"
      },
      {
        "range": [
          {
            "text": "儿童",
            "value": "儿童"
          },
          {
            "text": "教辅",
            "value": "教辅"
          },
          {
            "text": "文学社科",
            "value": "文学社科"
          },
          {
            "text": "艺术",
            "value": "艺术"
          },
          {
            "text": "经管励志",
            "value": "经管励志"
          },
          {
            "text": "考试法律",
            "value": "考试法律"
          },
          {
            "text": "科技生活",
            "value": "文创"
          }
        ]
      }
    ],
    "title": "分类",
    "label": "分类"
  },
  "coverImage": {
    "rules": [
      {
        "format": "file"
      }
    ],
    "title": "封面",
    "label": "封面"
  },
  "price": {
    "rules": [
      {
        "required": true,
        "errorMessage": "{title}不能为空"
      },
      {
        "format": "int"
      },
      {
        "minimum": 0,
        "errorMessage": "{title}不能小于 {minimum}"
      }
    ],
    "title": "单价",
    "label": "单价"
  },
  "cheapPrice": {
    "rules": [
      {
        "format": "int",
        "errorMessage": "{title}不能小于{minimum}"
      },
      {
        "minimum": 0,
        "errorMessage": "{title}不能小于{minimum}"
      }
    ],
    "title": "折扣价",
    "label": "折扣价"
  },
  "restCount": {
    "rules": [
      {
        "required": true,
        "errorMessage": "{title}不能为空"
      },
      {
        "format": "int"
      },
      {
        "minimum": 0,
        "errorMessage": "{title}不能小于 {minimum}"
      }
    ],
    "title": "余量",
    "label": "余量"
  },
  "brief": {
    "rules": [
      {
        "format": "string",
        "errorMessage": "{title}不能大于{maxLength}字"
      },
      {
        "maxLength": 1024,
        "errorMessage": "{title}不能大于{maxLength}字"
      }
    ],
    "title": "简介",
    "label": "简介"
  }
}

const enumConverter = {
  "classify_valuetotext": {
    "儿童": "儿童",
    "教辅": "教辅",
    "文学社科": "文学社科",
    "艺术": "艺术",
    "经管励志": "经管励志",
    "考试法律": "考试法律",
    "文创": "科技生活"
  }
}

function filterToWhere(filter, command) {
  let where = {}
  for (let field in filter) {
    let { type, value } = filter[field]
    switch (type) {
      case "search":
        if (typeof value === 'string' && value.length) {
          where[field] = new RegExp(value)
        }
        break;
      case "select":
        if (value.length) {
          let selectValue = []
          for (let s of value) {
            selectValue.push(command.eq(s))
          }
          where[field] = command.or(selectValue)
        }
        break;
      case "range":
        if (value.length) {
          let gt = value[0]
          let lt = value[1]
          where[field] = command.and([command.gte(gt), command.lte(lt)])
        }
        break;
      case "date":
        if (value.length) {
          let [s, e] = value
          let startDate = new Date(s)
          let endDate = new Date(e)
          where[field] = command.and([command.gte(startDate), command.lte(endDate)])
        }
        break;
      case "timestamp":
        if (value.length) {
          let [startDate, endDate] = value
          where[field] = command.and([command.gte(startDate), command.lte(endDate)])
        }
        break;
    }
  }
  return where
}

export { validator, enumConverter, filterToWhere }
