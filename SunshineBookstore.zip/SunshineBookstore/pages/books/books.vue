<template>
  <view class="books-container">
    <uni-search-bar placeholder="搜索图书名称/作者" @confirm="searchBooks"></uni-search-bar>
    <unicloud-db collection="books" :where="searchWhere" field="name,author,cover,price">
      <template #default="{data, loading, error}">
        <uni-list>
          <uni-list-item 
            v-for="(book, index) in data" 
            :key="index"
            @click="goToBookDetail(book._id)"
            class="book-item"
          >
            <image :src="book.cover" mode="widthFix" class="book-cover"></image>
            <view class="book-info">
              <text class="book-name">{{book.name}}</text>
              <text class="book-author">作者：{{book.author}}</text>
              <text class="book-price">¥{{book.price.toFixed(2)}}</text>
            </view>
          </uni-list-item>
        </uni-list>
        <view class="empty" v-if="data.length === 0 && !loading">暂无图书数据</view>
      </template>
    </unicloud-db>
  </view>
</template>

<script>
export default {
	  data() {
		return {
		  searchWhere: {} // 搜索条件
		};
	  },
	  methods: {
		// 搜索图书
		searchBooks(e) {
		  const keyword = e.value;
		  if (keyword) {
			this.searchWhere = {
			  $or: [
				{ name: new RegExp(keyword, 'i') }, // 模糊查询图书名
				{ author: new RegExp(keyword, 'i') } // 模糊查询作者
			  ]
			};
		  } else {
			this.searchWhere = {}; // 清空搜索条件，显示全部
		  }
		},
		// 跳转到详情页
		goToBookDetail(bookId) {
		  uni.navigateTo({ url: `/pages/bookDetail/bookDetail?bookId=${bookId}` });
		}
	  }
	};
</script>

<style scoped>
	.books-container {
	  padding: 20rpx;
	  background-color: #f5f5f5;
	  min-height: 100vh;
	}
	.book-item {
	  display: flex;
	  align-items: center;
	  background-color: #fff;
	  border-radius: 8rpx;
	  margin-bottom: 15rpx;
	  padding: 15rpx;
	}
	.book-cover {
	  width: 120rpx;
	  height: 160rpx;
	  object-fit: cover;
	  border-radius: 4rpx;
	}
	.book-info {
	  margin-left: 20rpx;
	  flex: 1;
	}
	.book-name {
	  font-size: 26rpx;
	  font-weight: 500;
	  margin-bottom: 8rpx;
	  display: block;
	}
	.book-author {
	  font-size: 22rpx;
	  color: #666;
	  margin-bottom: 8rpx;
	  display: block;
	}
	.book-price {
	  font-size: 24rpx;
	  color: #e74c3c;
	  font-weight: bold;
	}
	.empty {
	  text-align: center;
	  color: #999;
	  font-size: 24rpx;
	  margin-top: 50rpx;
	}
</style>