<template>
  <view class="detail-container">
    <!-- 返回键 -->
    <view class="back-btn" @click="goBack">
      <uni-icon type="back" size="36" color="#333"></uni-icon>
    </view>

    <!-- 图书详情内容 -->
    <view class="detail-content">
      <image :src="book.cover" mode="widthFix" class="detail-cover"></image>
      <view class="detail-info">
        <text class="detail-name">{{book.name}}</text>
        <text class="detail-author">作者：{{book.author}}</text>
        <text class="detail-press">出版社：{{book.press}}</text>
        <text class="detail-publishTime">出版时间：{{book.publishTime}}</text>
        <text class="detail-price">¥{{book.price.toFixed(2)}}</text>
        <button class="add-btn">加入书架</button>
      </view>

      <!-- 图书简介 -->
      <view class="detail-desc">
        <text class="desc-title">图书简介</text>
        <text class="desc-content">{{book.desc}}</text>
      </view>
    </view>
  </view>
</template>

<script>
export default {
	  data() {
		return {
		  book: {} // 图书详情数据
		};
	  },
	  onLoad(options) {
		const bookId = options.bookId;
		this.getBookDetail(bookId); // 加载图书详情
	  },
	  methods: {
		// 获取图书详情
		getBookDetail(bookId) {
		  const db = uniCloud.database();
		  db.collection('books').doc(bookId).get({
			success: (res) => {
			  this.book = res.result.data;
			},
			fail: () => {
			  uni.showToast({ title: '获取详情失败', icon: 'none' });
			}
		  });
		},
		// 返回上一页（列表页）
		goBack() {
		  uni.navigateBack();
		}
	  }
	};
</script>

<style scoped>
	.detail-container {
	  background-color: #f5f5f5;
	  min-height: 100vh;
	  position: relative;
	  padding-top: 30rpx;
	}
	.back-btn {
	  position: fixed;
	  top: 20rpx;
	  left: 20rpx;
	  z-index: 999;
	  background-color: rgba(255,255,255,0.8);
	  width: 60rpx;
	  height: 60rpx;
	  border-radius: 50%;
	  display: flex;
	  justify-content: center;
	  align-items: center;
	  box-shadow: 0 2rpx 10rpx rgba(0,0,0,0.1);
	}
	.detail-content {
	  padding: 20rpx;
	}
	.detail-cover {
	  width: 240rpx;
	  height: 320rpx;
	  object-fit: cover;
	  border-radius: 12rpx;
	  margin: 0 auto 30rpx;
	  box-shadow: 0 5rpx 15rpx rgba(0,0,0,0.1);
	}
	.detail-info {
	  background-color: #fff;
	  border-radius: 12rpx;
	  padding: 30rpx;
	  margin-bottom: 30rpx;
	}
	.detail-name {
	  font-size: 34rpx;
	  font-weight: bold;
	  color: #2c3e50;
	  display: block;
	  margin-bottom: 15rpx;
	}
	.detail-author, .detail-press, .detail-publishTime {
	  font-size: 26rpx;
	  color: #666;
	  display: block;
	  margin-bottom: 15rpx;
	}
	.detail-price {
	  font-size: 32rpx;
	  color: #e74c3c;
	  font-weight: bold;
	  display: block;
	  margin-bottom: 20rpx;
	}
	.add-btn {
	  background-color: #2c3e50;
	  color: #fff;
	  border-radius: 30rpx;
	  width: 100%;
	  height: 80rpx;
	  font-size: 28rpx;
	}
	.detail-desc {
	  background-color: #fff;
	  border-radius: 12rpx;
	  padding: 30rpx;
	}
	.desc-title {
	  font-size: 30rpx;
	  font-weight: bold;
	  color: #2c3e50;
	  display: block;
	  margin-bottom: 20rpx;
	}
	.desc-content {
	  font-size: 26rpx;
	  color: #333;
	  line-height: 1.8;
	}
</style>