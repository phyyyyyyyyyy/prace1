<template>
	<view class="page">
		<!-- header 开始 -->
		<view class="header">
			<!-- left location -->
			<!-- left location 结束-->
			<!-- right location 开始 -->
			<view class="uni-search-box">
				<uni-search-bar placeholder="搜索书籍" bg-color="#ffff7f" cancel-button="none" :radius="40">
				</uni-search-bar>
			</view>
			<!-- right location 开始 -->
		</view>
		<!-- header 结束 -->
		<!-- 首页分类开始 -->
		<view class="classify_wrap">
			<!-- 横向选择开始 -->
			<view class="classify_scroll_x">
				<scroll-view scroll-x="true" >
					<!-- 标签选择开始 -->
					<view class="segmented-wrap">
						<unicloud-db v-slot:default="{data, loading, error, options}" collection="bookclassify">
							<view v-if="error">{{error.message}}</view>
							<view v-else>
								<uni-segmented-control
									:current="current" 
									:values="data[0].classify" 
									styleType="text"
									activeColor="red"
									@clickItem="onClickItem">
								</uni-segmented-control>
							</view>
						</unicloud-db>
					</view>
					<!-- 标签选择结束 -->
				</scroll-view>
			</view>
			<!-- 横向选择结束 -->
			<!-- 分类 icon 开始 -->
			<view class="classify_icon">
				<uni-icons type="list" size="28" color="gray" @click="goToGrid"></uni-icons>
			</view>
			<!-- 分类 icon 结束 -->
		</view>
		<!-- 首页分类结束 -->
		<view class="content">
			<view v-if="current === 0">
				<!-- 轮播图 开始 -->
				<view class="uni-margin-wrap">
					<unicloud-db v-slot:default="{data, loading, error, options}" collection="opendb-banner">
						<view v-if="error">{{error.message}}</view>
						<view v-else>
							<swiper class="swiper" circular :indicator-dots="indicatorDots" :autoplay="autoplay" :interval="interval"
								:duration="duration">
								<swiper-item v-for="(item, index) in data" :key="item._id">
									<view class="swiper-item">
										<image class="banner-image" :src="item.bannerfile.url" mode="aspectFill" :draggable="false" />
									</view>
								</swiper-item>
							</swiper>
						</view>
					</unicloud-db>
				</view>
				<!-- 轮播图 结束 -->
				<!-- vip 卡片开始 -->
				<view class="">
					<uni-card :title="vipTitle" :thumbnail="vipIcon" margin="Spx">
						<uni-grid :column="column" :show-border="false" :square="false">
							<uni-grid-item v-for="(item, index) in vipItems">
								<view class="grid-item-box">
									<image :src="item.icon" style="width: 60rpx; height: 60rpx;" mode="aspectFill"></image>
									<text>{{ item.text }}</text>
								</view>
							</uni-grid-item>
						</uni-grid>
					</uni-card>
				</view>
				<!-- vip 卡片结束 -->
				<!-- 书籍列表开始 -->
				<view class="bookList">
					<unicloud-db v-slot:default="{data, loading, error, options}" collection="sunshine-book">
						<view v-if="error">{{error.message}}</view>
						<view v-else>
							<uni-list>
								<uni-list-item v-for="(item, index) in data" showArrow :clickable="true" @click="handleItemClick(item._id)">
									<template v-slot:header>
									    <view class="slot-box">
									      <image class="slot-image" :src="item.coverImage.url" mode="widthFix"></image>
									    </view>
									</template>
									<template v-slot:body>
									    <view class="bookName">
									      <text>{{item.bookName}}</text>
									    </view>
									    <view class="author">
									      <text>作者 | {{ item.author }}</text>
									      <text>出版社 | {{ item.publisher }}</text>
									    </view>
									    <view class="price">
									      <text class="cheapPrice">¥ {{ getYuan(item.cheapPrice) }}</text>
									      <text>&nbsp;</text>
									      <text class="bookPrice"> ¥ {{ getYuan(item.price) }}</text>
									    </view>
									</template>
								</uni-list-item>
							</uni-list>
						</view>
					</unicloud-db>
				</view>
				<!-- 书籍列表结束 -->
			</view>
			<view v-if="current === 1">
				选项卡2的内容
			</view>
			<view v-if="current === 2">
				选项卡3的内容
			</view>
		</view>
	</view>
</template>

<script>
  export default {
    data() {
      return {
			indicatorDots: true,
			autoplay: true,
			interval: 2000,
			duration: 500,
			current:0,
			vipIcon:'/static/vip/vipIcon.png',
			column: 3,
			vipIcon: '/static/vip/vipIcon.png',
			vipTitle:'会员权益',
			vipItems: [
				{text: '余额宝', icon: '/static/vip/yuebao.png'},
				{text: '火车票机票', icon: '/static/vip/huochepiao.png'},
				{text: '借呗', icon: '/static/vip/jiebei.png'},
				{text: '转账', icon: '/static/vip/zhuanzhang.png'},
				{text: '我的信用卡', icon: '/static/vip/xinyongka.png'},
				{text: '手机营业厅', icon: '/static/vip/shouji.png'},
				{text: '高德团购爆品', icon: '/static/vip/gaode.png'},
				{text: '市民中心', icon: '/static/vip/shiminzhongxin.png'},
				{text: '冀时办', icon: '/static/vip/jishiban.png'},
			],
      }
    },
    methods: {
		handleItemClick(id) {
		  uni.navigateTo({
		    url: '/pages/sunshine-book/sunshine-book?id=' + id
		  })
		},
		getYuan(data){
			let yuan = Math.floor(data / 100)
			let fen = data % 100
			if(fen < 0) fen = '0'+fen
			return yuan+'.'+fen
		},
		onClickItem(e){
			if(this.current !== e.currentIndex){
				this.current = e.currentIndex
			}
		},
		goToGrid(){
			uni.switchTab({
				url:'/pages/grid/grid'
			})
		},
    }
  }
</script>
<style scoped>
	view {
		display: flex;
		box-sizing: border-box;
		flex-direction: column;
	}
	.pages {
		background-color: #FFFFFF;
	}
	.header{
		display: flex;
		flex-direction: row;
		padding-left: 10px;
	}
	.location{
		display: flex;
		flex-direction: row;
		height: 50px;
		line-height: 50px;
		font-size: 12px;
	}
	.uni-search-box {
		background-color: #FFFFFF;
		height: 50px;
		width: 100%;
	}
    .classify_wrap{
		width: 750rpx;
		display: flex;
		flex-direction: row;
	}
	.classify_scroll_x{
		white-space: nowrap;
		width: 650rpx;
		background-color: #FFFFFF;
		margin-top: 5rpx;
		margin-bottom: 8rpx;
		padding: 2px;
	}
	.classify_icon{
		display: flex;
		flex: 1;
		background-color: #FFFFFF;
		margin-left: 3rpx;/*  margin:5rpx 0 8rpx 3rpx上 右 下 左 */
		margin-top: 5rpx;
		margin-bottom: 8rpx;
	justify-content: center;
		text-align: center;
	}
    .segmented-wrap{
      width: 1200rpx;
    }
	/* .scroll-view-item_H {
		display: inline-block;
		width: 150rpx;
		height: 100rpx;
		line-height: 90rpx;
		text-align: center;
		font-size: 16px;
		border: 1px solid yellow;
	}
	.scroll-view-item_selected{
		border-bottom: 2px solid red;
	} */
	.uni-margin-wrap{
	    margin-top: 5rpx;
				}
	.swiper{
	    height: 315rpx;
				}
	.banner-image {
		width: 750rpx;
		height: 315rpx;
				}
	.uni-bg-red{
			background-color: red;
		}
	.uni-bg-green{
			background-color: green;
		}
	.uni-bg-blue{
			background-color: blue;
		}
	.uni-bg-pink{
		background-color:#fab9ff;
	}
	.grid-item-box {
			text-align: center;
			justify-content: center;
			padding: 20rpx 0 0 0;
	}
	.grid-item-box image{
		margin: 0 auto;
	}
	.slot-box {
	  display: flex;
	  flex-direction: row;
	  align-items: center;
	}
	
	.slot-image {
	  display: block;
	  margin-right: 10px;
	  width: 200rpx;
	  height: 200rpx;
	}
	.bookName{
	  font-size: 30rpx;
	  display: -webkit-box;
	  line-height: 1.5em;
	  -webkit-box-orient: vertical;
	  -webkit-line-clamp: 2;
	  overflow: hidden;
	  text-overflow: ellipsis;
	  margin-bottom: 5rpx;
	}
	.author{
	  font-size: 24rpx;
	  white-space: nowrap; /* 禁止换行 */
	  overflow: hidden; /* 隐藏溢出内容 */
	  text-overflow: ellipsis; /* 使用省略号表示文本溢出 */
	  word-break: break-all; /* 允许在单词内换行 */
	  margin-bottom: 10rpx;
	  color: #666666;
	}
	.price {
	  display: flex;
	  flex-direction: row;
	  line-height: 40rpx;
	}
	.cheapPrice{
	  font-size: 40rpx;
	  color: #000000;
	}
	.bookPrice{
	  font-size: 24rpx;
	  color: #AAAAAA;
	  text-decoration-line: line-through;
	}
</style>