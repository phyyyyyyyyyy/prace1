<template>
  <view class="container">
    <unicloud-db ref="udb" v-slot:default="{data, loading, error, options}" :options="options" :collection="collectionList" field="bookName,author,publisher,ISBN,classify,coverImage,price,cheapPrice,restCount,brief" :where="queryWhere" :getone="true" :manual="true">
      <view v-if="error">{{error.message}}</view>
      <view v-else-if="loading">
        <uni-load-more :contentText="loadMore" status="loading"></uni-load-more>
      </view>
      <view v-else-if="data">
        <view>
          <text>书名</text>
          <text>{{data.bookName}}</text>
        </view>
        <view>
          <text>作者</text>
          <text>{{data.author}}</text>
        </view>
        <view>
          <text>出版社</text>
          <text>{{data.publisher}}</text>
        </view>
        <view>
          <text>ISBN</text>
          <text>{{data.ISBN}}</text>
        </view>
        <view>
          <text>分类</text>
          <text>{{options.classify_valuetotext[data.classify]}}</text>
        </view>
        <view>
          <text>封面</text>
          <!-- <uni-file-picker v-if="data.coverImage && data.coverImage.fileType == 'image'" :value="data.coverImage" :file-mediatype="data.coverImage && data.coverImage.fileType" return-type="object" readonly></uni-file-picker>
          <uni-link v-else-if="data.coverImage" :href="data.coverImage.url" :text="data.coverImage.url"></uni-link>
          <text v-else></text> -->
		  <image :src="data.coverImage.url" mode="aspectFill"></image>
        </view>
        <view>
          <text>单价</text>
          <text>{{data.price}}</text>
        </view>
        <view>
          <text>折扣价</text>
          <text>{{data.cheapPrice}}</text>
        </view>
        <view>
          <text>余量</text>
          <text>{{data.restCount}}</text>
        </view>
        <view>
          <text>简介</text>
          <text>{{data.brief}}</text>
        </view>
      </view>
    </unicloud-db>
    <!-- <view class="btns">
      <button type="primary" @click="handleUpdate">修改</button>
      <button type="warn" class="btn-delete" @click="handleDelete">删除</button>
    </view> -->
  </view>
</template>

<script>
  // 由schema2code生成，包含校验规则和enum静态数据
  import { enumConverter } from '../../js_sdk/validator/sunshine-book.js'
  const db = uniCloud.database()

  export default {
    data() {
      return {
        queryWhere: '',
        collectionList: "sunshine-book",
        loadMore: {
          contentdown: '',
          contentrefresh: '',
          contentnomore: ''
        },
        options: {
          // 将scheme enum 属性静态数据中的value转成text
          ...enumConverter
        }
      }
    },
    onLoad(e) {
      this._id = e.id
    },
    onReady() {
      if (this._id) {
        this.queryWhere = '_id=="' + this._id + '"'
      }
    },
    methods: {
      handleUpdate() {
        // 打开修改页面
        uni.navigateTo({
          url: './edit?id=' + this._id,
          events: {
            // 监听修改页面成功修改数据后, 刷新当前页面数据
            refreshData: () => {
              this.$refs.udb.loadData({
                clear: true
              })
            }
          }
        })
      },
      handleDelete() {
        this.$refs.udb.remove(this._id, {
          success: (res) => {
            // 删除数据成功后跳转到list页面
            uni.navigateTo({
              url: './list'
            })
          }
        })
      }
    }
  }
</script>

<style>
  .container {
    padding: 10px;
  }

  .btns {
    margin-top: 10px;
    /* #ifndef APP-NVUE */
    display: flex;
    /* #endif */
    flex-direction: row;
  }

  .btns button {
    flex: 1;
  }

  .btn-delete {
    margin-left: 10px;
  }
</style>
