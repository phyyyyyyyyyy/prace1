import uniId from 'uni-id'

// 微信快捷登录
export function login(options) {
  return new Promise((resolve, reject) => {
    uniId.login({
      provider: options.provider, // 传入 'weixin'
      success: (res) => resolve(res),
      fail: (err) => reject(err)
    });
  });
}

// 退出登录
export function logout() {
  uniId.logout();
  uni.removeStorageSync('uni_id_token'); // 清除登录态缓存
}

// 获取当前用户信息
export function getUserInfo() {
  const userInfo = uniId.getUserInfo();
  return userInfo || null;
}

// 修改密码（扩展方法，供 editPassword 页使用）
export function updatePassword(oldPwd, newPwd) {
  return new Promise((resolve, reject) => {
    uniId.updatePwd({
      oldPwd,
      newPwd,
      type: 'password'
    }).then(res => resolve(res)).catch(err => reject(err));
  });
}