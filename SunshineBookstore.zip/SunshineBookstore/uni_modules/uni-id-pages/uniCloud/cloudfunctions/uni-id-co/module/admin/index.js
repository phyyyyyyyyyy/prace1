module.exports = {
  addUser: require('./add-user'),
  updateUser: require('./update-user')
}
