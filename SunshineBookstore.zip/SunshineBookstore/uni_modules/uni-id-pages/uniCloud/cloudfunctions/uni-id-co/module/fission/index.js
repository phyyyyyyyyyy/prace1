module.exports = {
  acceptInvite: require('./accept-invite'),
  getInvitedUser: require('./get-invited-user')
}
